//
//  UIView+DCAdditions.h
//
//  Created by Paddy O'Brien on 2013-10-22.
//
//

#import <UIKit/UIKit.h>

@interface UIView (DCAdditions)
@property (nonatomic, readonly, strong) UIColor *dc_originalBackgroundColor;
@end
